
let all=[];fetch("questions.json").then(r=>r.json()).then(d=>all=d);
function shuffle(a){return a.sort(()=>Math.random()-0.5)}
let test=[],i=0,s=0,ans=[];
function start(){test=shuffle([...all]).slice(0,20);i=0;s=0;ans=[];show();}
function show(){
 if(i>=20){let h=`<h2>Rezultati ${s}/20</h2>`;ans.filter(x=>!x.ok).forEach(g=>h+=`<p><b>${g.q}</b><br>Përgjigjja jote:${g.y}<br>Saktë:${g.c}</p>`);q.innerHTML=h;return;}
 let t=test[i],opts=t.options.map((o,k)=>`<button onclick="pick('${"ABCD"[k]}')">${"ABCD"[k]}. ${o}</button><br>`).join("");
 q.innerHTML=`<h3>${i+1}/20</h3><p>${t.question}</p>${opts}`;
}
function pick(l){let t=test[i],ok=l==t.answer;if(ok)s++;ans.push({ok,q:t.question,y:l,c:t.answer});i++;show();}
